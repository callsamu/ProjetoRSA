---
title: facil.io - FIOBJ String API
sidebar: 0.6.x/_sidebar.md
---
# {{{title}}}

## Overview

This documentation is incomplete. I would love your help to finish it up. Until that time, please read the documentation in [the `fiobj_str.h` header file](https://github.com/boazsegev/facil.io/blob/master/lib/facil/core/types/fiobj/fiobj_str.h).
