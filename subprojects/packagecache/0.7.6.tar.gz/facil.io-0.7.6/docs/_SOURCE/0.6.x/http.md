---
title: facil.io - HTTP API
sidebar: 0.6.x/_sidebar.md
---
# {{{title}}}

The facil.io framework offers an HTTP/1.1 and Websocket implementation which can be found in the "http" folder.

This implementation includes a naive HTTP client as well as other features.

## Overview

This documentation is incomplete. I would love your help to finish it up. Until that time, please read the documentation in [the `http.h` header file](https://github.com/boazsegev/facil.io/blob/master/lib/facil/http/http.h).

### example

## Constants

## Types

## Functions

## Important Notes
