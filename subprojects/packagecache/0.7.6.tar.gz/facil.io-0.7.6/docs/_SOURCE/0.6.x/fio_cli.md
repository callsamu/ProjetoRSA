---
title: facil.io - CLI helpers.
sidebar: 0.6.x/_sidebar.md
---
# Command Line Helper

This documentation is incomplete. I would love your help to finish it up. Until that time, please read the documentation in [the `fio_cli.h` header file](https://github.com/boazsegev/facil.io/blob/master/lib/facil/services/fio_cli.h).

## Overview

The `fio_cli.h` helper was created to make command line interfaces easier to manage, adding automatic argument documentation, aliases, string to integer conversion, etc'.

### example

## Constants

## Types

## General Functions

## Socket Initialization and State

## Sending / Receiving Data

## Read/Write Hooks

## Important Notes
