---
title: facil.io - Websockets API
sidebar: 0.6.x/_sidebar.md
---
# {{{title}}}

The facil.io framework offers an HTTP/1.1 and Websocket implementation which can be found in the "http" folder.

This implementation includes pub/sub services for Websocket connections as well as other features.

## Overview

This documentation is incomplete. I would love your help to finish it up. Until that time, please read the documentation in [the `websockets.h` header file](https://github.com/boazsegev/facil.io/blob/master/lib/facil/http/websockets.h).

### example

## Constants

## Types

## Functions

## Important Notes
