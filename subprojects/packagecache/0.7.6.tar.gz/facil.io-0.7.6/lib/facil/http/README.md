# The HTTP / WebSocket extensions.

These are extensions that allow facil.io to easily implement HTTP and WebSocket services. For more details, visit [facil.io's website](http://facil.io).

**Notice**: these extensions requires the core facil.io library (`fio.h` and `fio.c`) and it's `FIOBJ` soft type system (the `fiobj` folder, included through `fiobj.h`).
