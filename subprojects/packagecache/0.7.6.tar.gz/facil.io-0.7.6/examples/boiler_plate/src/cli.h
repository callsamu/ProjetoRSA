#ifndef H_APP_CLI_H
#define H_APP_CLI_H

void initialize_cli(int argc, char const *argv[]);
void free_cli(void);

#endif
